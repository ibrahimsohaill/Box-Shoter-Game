﻿using System.Collections;

using UnityEngine;

public class NewBehaviourScript1 : MonoBehaviour
{
	public enum MotionDirection { Spin, MoveRight, MoveUp }
	public MotionDirection ChoseMotionDirection = MotionDirection.Spin;
	public float SpinSpeed = 180f;
	public float MoveSpeed = 0.1f;
	// Update is called once per frame
	void Update()
	{
		switch (ChoseMotionDirection)
		{
			case MotionDirection.Spin:				
					gameObject.transform.Rotate(Vector3.up * SpinSpeed * Time.deltaTime);
				break;
			case MotionDirection.MoveUp:
				
					gameObject.transform.Translate(Vector3.up * Mathf.Cos(Time.timeSinceLevelLoad) * MoveSpeed);
				break;
			case MotionDirection.MoveRight:
				gameObject.transform.Translate(Vector3.right * Mathf.Cos(Time.timeSinceLevelLoad) * MoveSpeed);
				break;
		}
	}
}