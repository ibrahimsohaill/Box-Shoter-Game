﻿using System.Collections;
using UnityEngine;

public class NewBehaviourScript : MonoBehaviour
{
    public float MoveSpeed = 3.0f;
    public float Gravity = 9.81f;
    private CharacterController MyController;

    void Start()
    {
        MyController = gameObject.GetComponent<CharacterController>();
    }

    void Update()
    {
        Vector3 movementZ = Input.GetAxis("Vertical") * Vector3.forward * MoveSpeed * Time.deltaTime;
        Vector3 movementX = Input.GetAxis("Horizontal") * Vector3.right * MoveSpeed * Time.deltaTime;
        Vector3 movement = transform.TransformDirection(movementX + movementZ);
        movement.y -= Gravity;
        MyController.Move(movement);
    }

}